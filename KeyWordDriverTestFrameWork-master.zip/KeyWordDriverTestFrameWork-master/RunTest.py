"""
------------------------------------
@Time : 2019/8/3 14:20
@Auth : linux超
@File : RunTest.py
@IDE  : PyCharm
@Motto: Real warriors,dare to face the bleak warning,dare to face the incisive error!
------------------------------------
"""
from testCases.Test126SendMailWithAttachment import test_126_mail_send_with_att


if __name__ == '__main__':
    test_126_mail_send_with_att()
